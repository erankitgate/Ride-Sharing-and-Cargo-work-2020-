**How to build?

**PRE-REQ: This code needs OSRM to be build. Also, it needs data to be given in the input.
This setup was done by the authors and tests were performed with real-world data.
**NOTE: Sample data file and some of the code was lost due to server crash under heavy load of OSRM. We have tried to regenerate the code as it is on the similar line as Orienteering with Time Windows.

1. To run a single command you can use makefile. Just run 
    # make

2. Run the executable :
    # ./algoRideshare.out

3. To see overall output, see the paper for final results produced.