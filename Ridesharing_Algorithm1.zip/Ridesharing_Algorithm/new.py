import polyline

#def getPolyline(locations):
#	s = polyline.encode(locations)
#	return s
s = polyline.encode([(13.04995,80.2824),(13.12722,80.29003)], 5)
#print(s)
locations = polyline.decode("i`poDwd~xMnsu@vej@alv@oog@??")
print(locations)



#13.08268,80.27072;12.97977,80.25288;12.99946,80.11773;12.99946,80.11773
#28.92309,77.65596;28.64333,77.43472;28.92702,77.64216;28.92702,77.64216
