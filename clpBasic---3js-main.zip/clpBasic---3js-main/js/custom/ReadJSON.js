var cargoColorArray = ["Black", "Blue", "BlueViolate", "Brown", "Crimson", "DarkBlue", "DarkCyan", "DarkGoldenRod"];

//Requires localhost address
function readContainer() {
    $.getJSON(JSONFilePath, function (json) {
        //document.getElementById('cont-info').innerHTML = `Container ID : ${}, Volume Efficiency : ${json.container_percent_volume_loaded}%, Weight Efficiency : ${json.container_percent_weight_loaded}%`;
        let length = json.container_length;
        let width = json.container_width;
        let height = json.container_height;
        let tonnage = json.container_tonnage;
        let id = json.container_id;

        container = new Container(length, width, height, id, tonnage);
        scene.add(container.wireframeCube);

        document.getElementById('iteration-info').innerHTML = `ITERATION: ${json.EBFT_best_relative_iteration} OF VARIANT ${json.EBFT_best_orientation}`;
        containerDetails(container);
    });
}

function readCargoes() {
    $.getJSON(JSONFilePath, function (json) {
        var data = json.data; // <= going inside the data itself
        $.each(data, function (i, data) {
            totalCargoes++;
            cargoArray.push(new Cargo(container, data.dim1, data.dim2, data.dim3, data.length, data.width, data.height, data.orientation, data.x, data.y, data.z, data.color, data.id, data.weight, data.wall, data.row, data.column, data.priority));
        });
        console.log(totalCargoes);
        displayDefaultDetails();
    });
}

function containerDetails(container) {
    document.getElementById('cont-id').innerHTML = `Container ID : ${container.id}`;
    document.getElementById('cont-dimensions').innerHTML = `Container Dimensions : ${container.containerLength} x ${container.containerWidth} x ${container.containerHeight} cm (${container.volume} cm${"3".sup()})`;
    document.getElementById('cont-tonnage').innerHTML = `Container Tonnage : ${container.tonnage/1000} kg`;
}
