'use strict';

function setCuboidPosition(cube, x, y, z) {
    cube.position.x = x;
    cube.position.y = y;
    cube.position.z = z;
}

function setCuboidRotation(cube, x, y, z) {
    cube.rotation.x = x;
    cube.rotation.y = y;
    cube.rotation.z = z;
}
