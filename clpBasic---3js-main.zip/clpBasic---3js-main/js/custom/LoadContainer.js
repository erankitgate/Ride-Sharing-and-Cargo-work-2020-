'use strict';

//wireframe cube
//length = height
//height = length
class Container {
    constructor(length, width, height, id, tonnage) {
        this.containerLength = length;
        this.containerWidth = width;
        this.containerHeight = height;
        this.volume = length * width * height;

        //Visual transformation
        this.visualLength = width * visualScale;
        this.visualWidth = height * visualScale;
        this.visualHeight = length * visualScale;

        this.id = id;
        this.tonnage = tonnage;

        this.geometry = new THREE.BoxGeometry(this.visualLength, this.visualWidth, this.visualHeight);
        //this.geometry = new THREE.BoxGeometry(1,5,10);

        THREE.ImageUtils.crossOrigin = '';
        this.texture = THREE.ImageUtils.loadTexture('img/container.jpg');
        this.texture.anisotropy = renderer.getMaxAnisotropy();

        //var material = new THREE.MeshBasicMaterial( { color: "#dadada", wireframe: false, transparent: true })
        this.material = new THREE.MeshFaceMaterial([
            new THREE.MeshBasicMaterial({
                //color: 0x00ff00,
                map: this.texture,
                wireframe: false,
                side: THREE.DoubleSide //BackSide
            }),
            new THREE.MeshBasicMaterial({
                //color: 0xff0000,
                map: this.texture,
                wireframe: false,
                side: THREE.DoubleSide
            }),
            new THREE.MeshBasicMaterial({
                color: 0x0000ff,
                wireframe: true
            }),
            new THREE.MeshBasicMaterial({
                //color: 0xffff00,
                map: this.texture,
                wireframe: false,
                side: THREE.DoubleSide
            }),
            new THREE.MeshBasicMaterial({
                color: 0x00ffff,
                wireframe: true
            }),
            new THREE.MeshBasicMaterial({
                //color: 0xff00ff,
                map: this.texture,
                wireframe: false,
                side: THREE.DoubleSide
            })
        ]);

        this.wireframeCube = new THREE.Mesh(this.geometry, this.material);

        this.containerLeftLowerX = this.wireframeCube.position.x - this.visualLength / 2;
        this.containerLeftLowerY = this.wireframeCube.position.y - this.visualWidth / 2;
        this.containerleftLowerZ = this.wireframeCube.position.z - this.visualHeight / 2;
        setCuboidRotation(this.wireframeCube, 0, 0, 0)
    }
}

// basic cube
class Cargo {
    constructor(container, dim1, dim2, dim3, length, width, height, orientation, z, x, y, colorShade, mark, weight, wall, row, column, priority) {
        this.wall = wall;
        this.row = row;
        this.column = column;
        this.dim1 = dim1;
        this.dim2 = dim2;
        this.dim3 = dim3;
        this.cargoLength = length;
        this.cargoWidth = width;
        this.cargoHeight = height;
        this.orientation = orientation;
        this.volume = length * width * height;
        this.priority = priority;

        //Visual transformation
        this.visualLength = width * visualScale;
        this.visualWidth = height * visualScale;
        this.visualHeight = length * visualScale;

        this.x = x;
        this.y = y;
        this.z = z;

        this.weight = weight;
        this.id = mark;

        this.cube = cubeMesh.clone();

        //text
        var canvas_ = document.createElement("canvas");
        let xc = canvas_.getContext("2d");
        canvas_.width = canvas_.height = 128;
        xc.font = "30px Helvetica";
        xc.fillStyle = colorShade;

        //xc.fillStyle = xc.createPattern(new Image("box.jpg"), "repeat");

        xc.fillRect(0, 0, 128, 128);
        xc.fillStyle = "white";
        xc.shadowColor = "#000";
        xc.shadowBlur = 3;
        xc.fillText(this.id, 10, 64);
        
        this.cube.material = new THREE.MeshStandardMaterial( { color: "white", flatShading: true, metalness: 0, roughness: 1});
        this.cube.material.map = new THREE.Texture(canvas_);
        this.cube.material.map.needsUpdate = true;
        
        this.cube.scale.x = this.visualLength;
        this.cube.scale.y = this.visualWidth;
        this.cube.scale.z = this.visualHeight;
        
        this.cube.material.polygonOffset = true;
        this.cube.material.polygonOffsetFactor = -0.1;

        // wireframe
        let geo = new THREE.EdgesGeometry(this.cube.geometry);
        let mat = new THREE.LineBasicMaterial({
            color: 0xffffff,
            linewidth: 1
        });

        let wireframe = new THREE.LineSegments(geo, mat);
        wireframe.renderOrder = 1; // make sure wireframes are rendered 2nd
        this.cube.add(wireframe);
        setCuboidPosition(this.cube, container.containerLeftLowerX + this.visualLength / 2 + x * visualScale, container.containerLeftLowerY + this.visualWidth / 2 + y * visualScale, container.containerleftLowerZ + this.visualHeight / 2 + z * visualScale);
        setCuboidRotation(this.cube, 0, 0, 0)
    }
}
