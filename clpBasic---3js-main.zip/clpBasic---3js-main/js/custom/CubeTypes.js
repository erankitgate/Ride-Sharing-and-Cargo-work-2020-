'use strict';

//wireframe cube
class Container {
    constructor(length, width, height, id, tonnage) {
        this.containerLength = length;
        this.containerWidth = width;
        this.containerHeight = height;
        this.volume = length * width * height;

        this.visualLength = width * visualScale;
        this.visualWidth = height * visualScale;
        this.visualHeight = length * visualScale;

        this.id = id;
        this.tonnage = tonnage;

        this.geometry = new THREE.BoxGeometry(this.visualLength, this.visualWidth, this.visualHeight);

        THREE.ImageUtils.crossOrigin = '';
        this.texture = THREE.ImageUtils.loadTexture('img/container.jpg');
        this.texture.anisotropy = renderer.getMaxAnisotropy();

        this.material = new THREE.MeshFaceMaterial([
            new THREE.MeshBasicMaterial({
                //color: 0x00ff00,
                map: this.texture,
                wireframe: false,
                side: THREE.DoubleSide //BackSide
            }),
            new THREE.MeshBasicMaterial({
                //color: 0xff0000,
                map: this.texture,
                wireframe: false,
                side: THREE.DoubleSide
            }),
            new THREE.MeshBasicMaterial({
                color: 0x0000ff,
                wireframe: true
            }),
            new THREE.MeshBasicMaterial({
                //color: 0xffff00,
                map: this.texture,
                wireframe: false,
                side: THREE.DoubleSide
            }),
            new THREE.MeshBasicMaterial({
                color: 0x00ffff,
                wireframe: true
            }),
            new THREE.MeshBasicMaterial({
                //color: 0xff00ff,
                map: this.texture,
                wireframe: false,
                side: THREE.DoubleSide
            })
        ]);

        this.wireframeCube = new THREE.Mesh(this.geometry, this.material);

        this.containerLeftLowerX = this.wireframeCube.position.x - this.visualLength / 2;
        this.containerLeftLowerY = this.wireframeCube.position.y - this.visualWidth / 2;
        this.containerleftLowerZ = this.wireframeCube.position.z - this.visualHeight / 2;
        setCuboidRotation(this.wireframeCube, 0, 0, 0)
    }
}

// basic cube
class Cargo {
    constructor(container, length, width, height, z, x, y, colorShade, mark, weight) {
        this.cargoLength = length;
        this.cargoWidth = width;
        this.cargoHeight = height;
        this.volume = length * width * height;

        this.visualLength = width * visualScale;
        this.visualWidth = height * visualScale;
        this.visualHeight = length * visualScale;

        this.x = x;
        this.y = y;
        this.z = z;

        this.weight = weight;
        this.id = mark;

        this.geometry = new THREE.BoxGeometry(this.visualLength, this.visualWidth, this.visualHeight);

        //text
        let canvas_ = document.createElement("canvas");
        let xc = canvas_.getContext("2d");
        canvas_.width = canvas_.height = 128;
        xc.font = "30px Helvetica";
        xc.fillStyle = colorShade;
        xc.fillRect(0, 0, 128, 128);
        xc.fillStyle = "white";
        xc.shadowColor = "#000";
        xc.shadowBlur = 3;
        xc.fillText(this.id, 10, 64);

        this.material = new THREE.MeshBasicMaterial({
            map: new THREE.Texture(canvas_),
            transparent: true
        });
        this.material.map.needsUpdate = true;
        this.material.polygonOffset = true;
        this.material.polygonOffsetFactor = -0.1;

        this.cube = new THREE.Mesh(this.geometry, this.material);

        // wireframe
        let geo = new THREE.EdgesGeometry(this.cube.geometry);
        let mat = new THREE.LineBasicMaterial({
            color: 0xffffff,
            linewidth: 1
        });
        
        let wireframe = new THREE.LineSegments(geo, mat);
        wireframe.renderOrder = 1; // make sure wireframes are rendered 2nd
        this.cube.add(wireframe);
        setCuboidPosition(this.cube, container.containerLeftLowerX + this.visualLength / 2 + x * visualScale, container.containerLeftLowerY + this.visualWidth / 2 + y * visualScale, container.containerleftLowerZ + this.visualHeight / 2 + z * visualScale);
        setCuboidRotation(this.cube, 0, 0, 0)
    }

}
