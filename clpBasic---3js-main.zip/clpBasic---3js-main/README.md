# clpBasic---3js

Visualization of clpBasic output using Three.js

Set var JSONFilePath in index.js to appropriate JSON file path to visualize

Sample JSON file is included in "json" folder
