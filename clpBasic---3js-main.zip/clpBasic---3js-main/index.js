'use strict';

// We need 3 things everytime we use Three.js
// Scene + Camera + Renderer
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
    75, //Field of view
    window.innerWidth / window.innerHeight, //Aspect ratio
    0.1, //Near
    1000000 //Far
);
const renderer = new THREE.WebGLRenderer({
    antialias: true
});

renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor("#222222"); //sets renderer background color
document.body.appendChild(renderer.domElement);
camera.position.z = 20;

// resize canvas on resize window
window.addEventListener('resize', () => {
    let width = window.innerWidth
    let height = window.innerHeight
    renderer.setSize(width, height)
    camera.aspect = width / height
    camera.updateProjectionMatrix()
});

// wireframe cube
//var containerLength = 1;
//var containerWidth = 1;
//var containerHeight = 1;
//var container = new Container(containerLength,containerWidth, containerHeight);
//scene.add(container.wireframeCube);

/*// basic cube
var cargoLength = 1;
var cargoWidth = 1;
var cargoHeight = 1;
var cargo = new Cargo(container, cargoHeight, cargoWidth, cargoLength, 0, 0, 0, "red",'A');
scene.add(cargo.cube)

var cargo2 = new Cargo(container, cargoLength, cargoWidth, cargoHeight, 1, 0, 0, "green",'B');
scene.add(cargo2.cube)

var cargo3 = new Cargo(container, cargoLength, cargoWidth, 2*cargoHeight, 0, 1, 0, "blue",'C');
scene.add(cargo3.cube)*/


// ambient light
var ambientLight = new THREE.AmbientLight(0xffffff, 0.2)
scene.add(ambientLight)

// point light
var pointLight = new THREE.PointLight(0xffffff, 1);
pointLight.position.set(25, 50, 25);
scene.add(pointLight);

/*//Handling mouse drag/move
var isDragging = false;
var previousMousePosition = {
    x: 0,
    y: 0
};

function onMouseDown() {
    isDragging = true;
}
document.addEventListener('mousedown', onMouseDown);

function onMouseMove(e) {
    var deltaMove = {
        x: e.offsetX-previousMousePosition.x,
        y: e.offsetY-previousMousePosition.y
    };

    if(isDragging) {
            
        var deltaRotationQuaternion = new THREE.Quaternion()
            .setFromEuler(new THREE.Euler(
                toRadians(deltaMove.y * 1),
                toRadians(deltaMove.x * 1),
                0,
                'XYZ'
            ));
        
        //cargo.cube.quaternion.multiplyQuaternions(deltaRotationQuaternion, cargo.cube.quaternion);
        //container.wireframeCube.quaternion.multiplyQuaternions(deltaRotationQuaternion, container.wireframeCube.quaternion);
    }
    
    previousMousePosition = {
        x: e.offsetX,
        y: e.offsetY
    };
}
document.addEventListener('mousemove', onMouseMove);

function onMouseUp() {
    isDragging = false;
}
document.addEventListener('mouseup', onMouseUp);*/

function animate() {
    requestAnimationFrame(animate)
    //cube.rotation.x += 0.04;
    //cube.rotation.y += 0.04;
    //wireframeCube.rotation.x -= 0.01;
    //wireframeCube.rotation.y -= 0.01;
    renderer.render(scene, camera)
}
animate()

/*// shim layer with setTimeout fallback
window.requestAnimFrame = (function(){
    return  window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        function(callback) {
            window.setTimeout(callback, 1000 / 60);
        };
})();

var lastFrameTime = new Date().getTime() / 1000;
var totalGameTime = 0;
function update(dt, t) {
    //console.log(dt, t);
    
    //camera.position.z += 1 * dt;
    //cube.rotation.x += 1 * dt;
    //cube.rotation.y += 1 * dt;
    
    setTimeout(function() {
        var currTime = new Date().getTime() / 1000;
        var dt = currTime - (lastFrameTime || currTime);
        totalGameTime += dt;
        
        update(dt, totalGameTime);
    
        lastFrameTime = currTime;
    }, 0);
}*/

var controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.minDistance = 1;
controls.maxDistance = 20;

var geometry = new THREE.BoxGeometry(1, 1, 1);

//this.material = new THREE.MeshStandardMaterial( { color: colorShade, flatShading: true, metalness: 0, roughness: 1});

var material = new THREE.MeshLambertMaterial( { color: "white", flatShading: true, metalness: 0, roughness: 1});

var cubeMesh = new THREE.Mesh(geometry, material);

function zoomModel(isZoomOut, scale) {
    if (isZoomOut) {
        controls.dollyIn(scale);
    } else {
        controls.dollyOut(scale);
    }
}

$(document).on('click', '#zoomIn', function () {
    //call this to make the model larger/ zoom in
    zoomModel(true, 4);
});

$(document).on('click', '#zoomOut', function () {
    // call this to make it smaller / zoom out
    zoomModel(false, 4);
});

var cargoCounter = 0;
var cargoArray = [];
var loaded = true;
var totalCargoes = 0;
var JSONFilePath = 'container-0-pickup-2021-10-11-ptype-IGNORE_PRIORITY-83.33.json';
var container;
const visualScale = 0.02;
var viewDistance = 1;
var volumeLoaded = 0,
    weightLoaded = 0;

document.addEventListener('DOMContentLoaded', function () {
    readContainer();
    readCargoes();
    document.getElementById('packing-info').innerHTML = `Packing Type: ${JSONFilePath.split('-')[7]}`;
}, false);

$(document).on('click', '#loadPrevious', function () {
    if (cargoCounter > 0) {
        --cargoCounter;
        let currentBox = cargoArray[cargoCounter];

        /*controls.reset();
        let targetViewDistance = (currentBox.z + currentBox.cargoLength) * visualScale;
        if(viewDistance > targetViewDistance) viewDistance = targetViewDistance;
        camera.position.z = viewDistance + 1;*/

        volumeLoaded -= currentBox.volume;
        weightLoaded -= currentBox.weight;
        removeEntity(cargoArray[cargoCounter].cube);
        if (cargoCounter > 0) {
            let currentBox = cargoArray[cargoCounter - 1];
            displayDetails(currentBox, cargoCounter);
        } else {
            displayDefaultDetails();
        }
    } else {
        loaded = false;
        totalCargoes = 0;
        alert("All unloaded!");
        displayDefaultDetails();
    }
});

$(document).on('click', '#loadNext', function () {
    if (!loaded) {
        readCargoes();
        console.log("Loaded");
        loaded = true;
        console.log("total: " + totalCargoes);
    }

    //var cargoLength = 1;
    //var cargoWidth = 1;
    //var cargoHeight = 1;
    //cargoArray.push(new Cargo(container, cargoHeight, cargoWidth, cargoLength, 0, 0, cargoCounter++, "crimson",'A'+cargoCounter));
    if (cargoCounter < totalCargoes) {
        let currentBox = cargoArray[cargoCounter];
        volumeLoaded += currentBox.volume;
        weightLoaded += currentBox.weight;
        scene.add(currentBox.cube);

        /*controls.reset();
        let targetViewDistance = (currentBox.z + currentBox.cargoLength) * visualScale;
        if(viewDistance < targetViewDistance) viewDistance = targetViewDistance;
        camera.position.z = viewDistance + 1;*/

        //console.log(currentBox.id.split("-")[0]);
        /*if(cargoCounter===0){
            responsiveVoice.speak(`First box is ${currentBox.id}, load in wall ${currentBox.wall}, layer ${currentBox.row} at position ${currentBox.column}`,"UK English Female", {pitch: 1});
        } else if(cargoCounter === totalCargoes-1){
            responsiveVoice.speak(`Last box is ${currentBox.id}, load in wall ${currentBox.wall}, layer ${currentBox.row} at position ${currentBox.column}`,"UK English Female", {pitch: 1});
        } else {
            responsiveVoice.speak(`Next box is ${currentBox.id}, load in wall ${currentBox.wall}, layer ${currentBox.row} at position ${currentBox.column}`,"UK English Female", {pitch: 1});
        }*/

        //document.getElementById('cont-volume-loaded').innerHTML = `Volume Loaded : ${cargoArray[cargoCounter].volumeLoaded} cm${"3".sup()}`;
        displayDetails(currentBox, cargoCounter + 1);
        ++cargoCounter;
    } else {
        if (totalCargoes === 0) {
            alert("Initial load!");
        } else {
            alert("All loaded!");
        }
    }
});

$(document).on('click', '#unloadAll', function () {
    /*for (; cargoCounter > 0;) {
        $("#loadPrevious").click();
        console.log("Unloaded");
    }*/
    location.reload(false); //If false, the page will be reloaded from cache, else from the server.
});

$(document).on('click', '#loadAll', function () {
    /*for (; cargoCounter < totalCargoes;) {
        $("#loadNext").click();
        console.log("Loaded");
    }*/

    loadLoop();
});

function loadLoop() {
    setTimeout(function () { //  call a 5ms setTimeout when the loop is called
        $("#loadNext").click();
        console.log("Loaded");
        if (cargoCounter < totalCargoes) { //  if the counter < 10, call the loop function
            loadLoop(); //  ..  again which will trigger another 
        } //  ..  setTimeout()
    }, 1000.0 / totalCargoes);
}

/*function readCargoes() {
    $.ajax({
        type: 'GET',
        url: 'test.json',
        success: function(response) {      // <= this is the change
            var data = response.data;      // <= going inside the data itself
            $.each(data, function(i, data){
                totalCargoes++;
                cargoArray.push(new Cargo(container, data.length, data.width, data.height, data.x,data.y,data.z, "crimson",'A'+i));
            });

        }
    });
}*/

function displayDetails(box, count) {
    let ratio = volumeLoaded / container.volume * 100;
    document.getElementById('cont-volume-loaded').innerHTML = `Volume Loaded : ${volumeLoaded} cm${"3".sup()} (${ratio.toFixed(3)} %)`;

    ratio = weightLoaded * 100 / container.tonnage;
    document.getElementById('cont-weight-loaded').innerHTML = `Weight Loaded : ${weightLoaded/1000.0} kg (${ratio.toFixed(3)} %)`;

    document.getElementById('cont-boxes-loaded').innerHTML = `Total #Boxes Loaded : ${count}`;
    document.getElementById('cont-boxes-not-loaded').innerHTML = `Remaining #Boxes : ${totalCargoes - count}`;

    document.getElementById('box-id').innerHTML = `Box ID : ${box.id}`;
    document.getElementById('box-priority').innerHTML = `Box Priority : ${box.priority}`;
    document.getElementById('box-location').innerHTML = `Box Location : (${box.z} , ${box.x} , ${box.y})`;
    document.getElementById('box-original-dimensions').innerHTML = `Original Dimensions : ${box.dim1} x ${box.dim2} x ${box.dim3} cm (${box.volume} cm${"3".sup()})`;
    document.getElementById('box-packed-dimensions').innerHTML = `Packed Dimensions : ${box.cargoLength} x ${box.cargoWidth} x ${box.cargoHeight} cm (${box.volume} cm${"3".sup()})`;
    document.getElementById('box-orientation').innerHTML = `Orientation : ${box.orientation}`;
    document.getElementById('box-weight').innerHTML = `Box Weight : ${box.weight/1000.0} kg`;
    document.getElementById('box-wall').innerHTML = `Box Wall : ${box.wall}`;
    document.getElementById('box-row').innerHTML = `Box Layer : ${box.row}`;
    document.getElementById('box-column').innerHTML = `Box Position : ${box.column}`;
}

function displayDefaultDetails() {
    document.getElementById('cont-volume-loaded').innerHTML = `Volume Loaded : 0%`;
    document.getElementById('cont-weight-loaded').innerHTML = `Weight Loaded : 0%`;
    document.getElementById('cont-boxes-total').innerHTML = `Total #Boxes : ${totalCargoes}`;
    document.getElementById('cont-boxes-loaded').innerHTML = `#Boxes Loaded : 0`;
    document.getElementById('cont-boxes-not-loaded').innerHTML = `Remaining #Boxes : ${totalCargoes - cargoCounter}`;
    document.getElementById('box-id').innerHTML = `Box ID : NA`;
    document.getElementById('box-original-dimensions').innerHTML = `Original Dimensions : NA`;
    document.getElementById('box-packed-dimensions').innerHTML = `Packed Dimensions : NA`;
    document.getElementById('box-orientation').innerHTML = `Orientation : NA`;
    document.getElementById('box-weight').innerHTML = `Box Weight : NA`;
    document.getElementById('box-wall').innerHTML = `Box Wall : NA`;
    document.getElementById('box-row').innerHTML = `Box Layer : NA`;
    document.getElementById('box-column').innerHTML = `Box Position : NA`;
}

document.addEventListener('mousewheel', (event) => {
    camera.position.z += event.deltaY / 500;
    //console.log(camera.position.z);
});

function removeEntity(object) {
    //var selectedObject = scene.getObjectByName(object.name);
    scene.remove(object);
    animate();
}

document.addEventListener('keydown', function (event) {
    const step = 1; // world units
    switch (event.keyCode) {
        case 87: //up, W
        case 38:
            camera.position.z -= step;
            break;
        case 83: //down, S
        case 40:
            camera.position.z += step;
            break;
        case 37: //left, A
        case 65:
            camera.position.x -= step;
            break;
        case 39: //right, D
        case 68:
            camera.position.x += step;
            break;
    }
    console.log(camera.position.z);
}, false);
